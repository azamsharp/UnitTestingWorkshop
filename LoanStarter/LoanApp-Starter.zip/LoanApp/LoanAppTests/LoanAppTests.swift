//
//  LoanAppTests.swift
//  LoanAppTests
//
//  Created by Mohammad Azam on 4/19/24.
//

import XCTest
@testable import LoanApp

final class LoanAppTests: XCTestCase {
    
    func testCalculateAPRInvokesGetCreditScore() async throws {
        
    }
    
    func testCalculateAPR() async throws {
        
    }
    
    func testThrowExceptionWhenCreditScoreNotFound() async throws {
        
    }
}
