//
//  LoanAppUITests.swift
//  LoanAppUITests
//
//  Created by Mohammad Azam on 4/24/24.
//

import XCTest

final class LoanAppUITests: XCTestCase {

    func testCalculateAPR() throws {
        
       
       
    }

}
