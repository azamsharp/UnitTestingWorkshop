//
//  BudgetAppApp.swift
//  BudgetApp
//
//  Created by Mohammad Azam on 4/17/24.
//

import SwiftUI

@main
struct BudgetAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
