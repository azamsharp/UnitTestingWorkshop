//
//  CustomerListScreenTests.swift
//  LoanAppTests
//
//  Created by Mohammad Azam on 4/27/24.
//

import XCTest
@testable import LoanApp

final class CustomerListScreenTests: XCTestCase {

    func testExample() {
        
        
    }

  

}
