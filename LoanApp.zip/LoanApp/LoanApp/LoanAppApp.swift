//
//  LoanAppApp.swift
//  LoanApp
//
//  Created by Mohammad Azam on 4/19/24.
//

import SwiftUI

@main
struct LoanAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
